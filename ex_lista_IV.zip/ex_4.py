# 4) Faça um programa para calcular a quantidade de barbante necessária, em centímetros, para amarrar um pacote com
# duas voltas de barbante sendo uma pela largura e outra pelo comprimento. Serão fornecidas a largura, a altura e o
# comprimento do pacote. Para amarrar as pontas do barbante são necessários 10 cm de barbante em cada ponta.

